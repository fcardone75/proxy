<?php

namespace Bni\Gpec\Client\Type;

use \Bni\Gpec\Client\Type\GetMailsResponse;

class GetMailsFromDateToDateResponse extends GetMailsResponse
{
}


<?php

namespace Bni\Gpec\Client\Type;

abstract class BaseResponse
{
}


<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class GetMailsToResponse implements ResultInterface
{
    /**
     * @var null | \Bni\Gpec\Client\Type\GetMailsToResponse
     */
    private ?\Bni\Gpec\Client\Type\GetMailsToResponse $GetMailsToResponse = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\GetMailsToResponse
     */
    public function getGetMailsToResponse() : ?\Bni\Gpec\Client\Type\GetMailsToResponse
    {
        return $this->GetMailsToResponse;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\GetMailsToResponse $GetMailsToResponse
     * @return static
     */
    public function withGetMailsToResponse(?\Bni\Gpec\Client\Type\GetMailsToResponse $GetMailsToResponse) : static
    {
        $new = clone $this;
        $new->GetMailsToResponse = $GetMailsToResponse;

        return $new;
    }
}


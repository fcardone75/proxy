<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class DeleteMailResponse implements ResultInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\DeleteMailResponse
     */
    private \Bni\Gpec\Client\Type\DeleteMailResponse $DeleteMailResponse;

    /**
     * @return \Bni\Gpec\Client\Type\DeleteMailResponse
     */
    public function getDeleteMailResponse() : \Bni\Gpec\Client\Type\DeleteMailResponse
    {
        return $this->DeleteMailResponse;
    }

    /**
     * @param \Bni\Gpec\Client\Type\DeleteMailResponse $DeleteMailResponse
     * @return static
     */
    public function withDeleteMailResponse(\Bni\Gpec\Client\Type\DeleteMailResponse $DeleteMailResponse) : static
    {
        $new = clone $this;
        $new->DeleteMailResponse = $DeleteMailResponse;

        return $new;
    }
}


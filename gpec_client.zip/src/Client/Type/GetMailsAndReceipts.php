<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class GetMailsAndReceipts implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\GetMailsAndReceiptsRequest
     */
    private \Bni\Gpec\Client\Type\GetMailsAndReceiptsRequest $GetMailsAndReceiptsRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\GetMailsAndReceiptsRequest $GetMailsAndReceiptsRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\GetMailsAndReceiptsRequest $GetMailsAndReceiptsRequest)
    {
        $this->GetMailsAndReceiptsRequest = $GetMailsAndReceiptsRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\GetMailsAndReceiptsRequest
     */
    public function getGetMailsAndReceiptsRequest() : \Bni\Gpec\Client\Type\GetMailsAndReceiptsRequest
    {
        return $this->GetMailsAndReceiptsRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\GetMailsAndReceiptsRequest $GetMailsAndReceiptsRequest
     * @return static
     */
    public function withGetMailsAndReceiptsRequest(\Bni\Gpec\Client\Type\GetMailsAndReceiptsRequest $GetMailsAndReceiptsRequest) : static
    {
        $new = clone $this;
        $new->GetMailsAndReceiptsRequest = $GetMailsAndReceiptsRequest;

        return $new;
    }
}


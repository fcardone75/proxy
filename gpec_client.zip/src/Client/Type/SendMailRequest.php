<?php

namespace Bni\Gpec\Client\Type;

use \Bni\Gpec\Client\Type\BaseRequest;

class SendMailRequest extends BaseRequest
{
    /**
     * @var null | \Bni\Gpec\Client\Type\MessageInfoSender
     */
    private ?\Bni\Gpec\Client\Type\MessageInfoSender $message = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\MessageInfoSender
     */
    public function getMessage() : ?\Bni\Gpec\Client\Type\MessageInfoSender
    {
        return $this->message;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\MessageInfoSender $message
     * @return static
     */
    public function withMessage(?\Bni\Gpec\Client\Type\MessageInfoSender $message) : static
    {
        $new = clone $this;
        $new->message = $message;

        return $new;
    }
}


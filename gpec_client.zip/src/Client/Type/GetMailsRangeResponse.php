<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class GetMailsRangeResponse implements ResultInterface
{
    /**
     * @var null | \Bni\Gpec\Client\Type\GetMailsRangeResponse
     */
    private ?\Bni\Gpec\Client\Type\GetMailsRangeResponse $GetMailsFromDateToDateResponse = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\GetMailsRangeResponse
     */
    public function getGetMailsFromDateToDateResponse() : ?\Bni\Gpec\Client\Type\GetMailsRangeResponse
    {
        return $this->GetMailsFromDateToDateResponse;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\GetMailsRangeResponse $GetMailsFromDateToDateResponse
     * @return static
     */
    public function withGetMailsFromDateToDateResponse(?\Bni\Gpec\Client\Type\GetMailsRangeResponse $GetMailsFromDateToDateResponse) : static
    {
        $new = clone $this;
        $new->GetMailsFromDateToDateResponse = $GetMailsFromDateToDateResponse;

        return $new;
    }
}


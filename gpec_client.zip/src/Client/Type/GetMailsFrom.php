<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class GetMailsFrom implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\GetMailsFromRequest
     */
    private \Bni\Gpec\Client\Type\GetMailsFromRequest $GetMailsFromRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\GetMailsFromRequest $GetMailsFromRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\GetMailsFromRequest $GetMailsFromRequest)
    {
        $this->GetMailsFromRequest = $GetMailsFromRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\GetMailsFromRequest
     */
    public function getGetMailsFromRequest() : \Bni\Gpec\Client\Type\GetMailsFromRequest
    {
        return $this->GetMailsFromRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\GetMailsFromRequest $GetMailsFromRequest
     * @return static
     */
    public function withGetMailsFromRequest(\Bni\Gpec\Client\Type\GetMailsFromRequest $GetMailsFromRequest) : static
    {
        $new = clone $this;
        $new->GetMailsFromRequest = $GetMailsFromRequest;

        return $new;
    }
}


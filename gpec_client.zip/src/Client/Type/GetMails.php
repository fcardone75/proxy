<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class GetMails implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\GetMailsRequest
     */
    private \Bni\Gpec\Client\Type\GetMailsRequest $GetMailsRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\GetMailsRequest $GetMailsRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\GetMailsRequest $GetMailsRequest)
    {
        $this->GetMailsRequest = $GetMailsRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\GetMailsRequest
     */
    public function getGetMailsRequest() : \Bni\Gpec\Client\Type\GetMailsRequest
    {
        return $this->GetMailsRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\GetMailsRequest $GetMailsRequest
     * @return static
     */
    public function withGetMailsRequest(\Bni\Gpec\Client\Type\GetMailsRequest $GetMailsRequest) : static
    {
        $new = clone $this;
        $new->GetMailsRequest = $GetMailsRequest;

        return $new;
    }
}


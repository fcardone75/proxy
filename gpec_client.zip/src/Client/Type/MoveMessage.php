<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class MoveMessage implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\MoveMessageRequest
     */
    private \Bni\Gpec\Client\Type\MoveMessageRequest $moveMessageRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\MoveMessageRequest $moveMessageRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\MoveMessageRequest $moveMessageRequest)
    {
        $this->moveMessageRequest = $moveMessageRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\MoveMessageRequest
     */
    public function getMoveMessageRequest() : \Bni\Gpec\Client\Type\MoveMessageRequest
    {
        return $this->moveMessageRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\MoveMessageRequest $moveMessageRequest
     * @return static
     */
    public function withMoveMessageRequest(\Bni\Gpec\Client\Type\MoveMessageRequest $moveMessageRequest) : static
    {
        $new = clone $this;
        $new->moveMessageRequest = $moveMessageRequest;

        return $new;
    }
}


<?php

namespace Bni\Gpec\Gpec;

use Bni\Gpec\Client\GpecClassmap;
use Bni\Gpec\Client\GpecClient;
use Http\Client\Common\Plugin\HeaderSetPlugin;
use Http\Client\Common\PluginClient;
use Http\Discovery\Psr18ClientDiscovery;
use Phpro\SoapClient\Caller\EngineCaller;
use Phpro\SoapClient\Caller\EventDispatchingCaller;
use Phpro\SoapClient\Soap\DefaultEngineFactory;
use Ramsey\Uuid\Uuid;
use Soap\ExtSoapEngine\ExtSoapOptions;
use Soap\Psr18Transport\Psr18Transport;
use Symfony\Component\EventDispatcher\EventDispatcher;


class CustomGpecFactory
{
    public function getFactory($wsdl)
    {

        // Recupera le env
        $rsmHostAlias = getenv(EnvUtility::BNI_GPEC_RSM_HOST_ALIAS);
        $rsmCaller = getenv(EnvUtility::BNI_GPEC_RSM_CALLER);


        // Popola l'array di headers
        $options = ['headers' => [
            'RSMHostAlias' => $rsmHostAlias,
            'RSMCaller' => $rsmCaller,
            'applicationId' => Uuid::uuid7()->toString(),
        ]];

        // Crea un nuovo oggetto HeaderSetPlugin con gli header appena creati
        $customHeaders = new HeaderSetPlugin($options['headers']);

        // Usa un Client Psr18
        $clientInterface = Psr18ClientDiscovery::find();
        $pluginClient = new PluginClient($clientInterface, [$customHeaders]);
        $transport = Psr18Transport::createForClient($pluginClient);

        // Recupera la classmap del client generato da wdsl
        $classMap = GpecClassmap::getCollection();
        $soapOptions = ExtSoapOptions::defaults($wsdl)->withClassMap($classMap);

        // Crea l'engine dalle opzioni soap e il transport
        $engine = DefaultEngineFactory::create($soapOptions, $transport);

        $eventDispatcher = new EventDispatcher();
        $caller = new EventDispatchingCaller(new EngineCaller($engine), $eventDispatcher);
        return new GpecClient($caller);
    }
}

<?php

namespace App\Service;

use Aws\CommandInterface;
use AWS\CRT\HTTP\Request;
use Aws\S3\S3Client;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\MessageFormatter;
use GuzzleHttp\Middleware;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use Psr\Http\Message\RequestInterface;

class CustomS3Client extends S3Client
{
    private string $accessToken;

    public static function create(array $config = [], ): S3Client
    {
        // Create logger
        $logger = new Logger('s3-logger');
        $logger->pushHandler(new StreamHandler('php://stdout', Logger::DEBUG));

        // Get the handler from config if it exists
        $handler = $config['http_handler'] ?? null;

        // Create handler stack
        $handlerStack = HandlerStack::create();

        // Add logging middleware
        $handlerStack->push(
            Middleware::log(
                $logger,
                new MessageFormatter(MessageFormatter::DEBUG)
            )
        );

        // If we have a custom handler, use it
        if ($handler instanceof \Closure) {
            $handlerStack->push($handler);
        }

        // Remove the http_handler from config as we've processed it
        unset($config['http_handler']);

        // Set up the HTTP configuration
        $config['http'] = [
            'handler' => $handlerStack,
            'verify' => $config['sslVerify'] === 'true'

        ];


        // Return new S3Client instance
        $s3client = new S3Client($config);
        $s3client->getHandlerList()->remove('signer');
        $s3client->getHandlerList()->appendBuild(
            function (callable $handler) use ($config) {
                return function (CommandInterface $command, RequestInterface $request = null) use ($handler, $config) {

                    // Rimuove tutti gli header x-amz-...
                    foreach ($request->getHeaders() as $header => $values) {
                        if (stripos($header, 'x-amz-') === 0) {
                            $request = $request->withoutHeader($header);
                        }
                    }

                    // Aggiunge Authorization: Bearer <TOKEN>

                    $request = $request->withHeader('Authorization', 'Bearer ' . self::readToken());

                    if (strlen($request->getUri()->getQuery()) > 0 && str_contains(strtoupper($request->getUri()->getQuery()), 'PREFIX') && !str_contains(strtoupper($request->getUri()->getQuery()), 'PREFIX=' . $_ENV['AWS_S3_BUCKET'])) {
                        parse_str($request->getUri()->getQuery(), $qs);
                        $uri = $request->getUri();
                        $path = $uri->getPath();
                        $newPath = substr($path, strlen($config['s3Bucket']) + 1);
                        $modifyUri = $uri->withPath($newPath);
                        $qs['prefix'] = $config['s3Bucket'] . '/' . $qs['prefix'];
                        $lastqs = http_build_query($qs);
                        $request = $request->withUri($modifyUri->withQuery($lastqs));
                    }
                    // Prosegue la catena chiamando il prossimo handler
                    return $handler($command, $request);
                };
            }
        );
        return $s3client;
    }

    private static function readToken()
    {
        $tokenFilePath = $_ENV['IBM_TOKEN_PATH'];
        if (!$tokenFilePath) {
            throw new \RuntimeException('The environment variable "IBM_TOKEN_PATH" is not set.');
        }

        if (!file_exists($tokenFilePath) || !is_readable($tokenFilePath)) {
            throw new \RuntimeException('The token file does not exist or is not readable: ' . $tokenFilePath);
        }

        $tokenFileContents = file_get_contents($tokenFilePath);

        if ($tokenFileContents === false) {
            throw new \RuntimeException('Failed to read the token file: ' . $tokenFilePath);
        }

        $tokenData = json_decode($tokenFileContents, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException('Failed to decode the JSON in the token file: ' . json_last_error_msg());
        }

        if (!isset($tokenData['access_token'])) {
            throw new \RuntimeException('The token file does not contain an "access_token" value.');
        }

        return $tokenData['access_token'];
    }
}

<?php
// src/Logger/CriticalErrorFormatter.php

namespace App\Monolog\Processor;

use Monolog\Formatter\LineFormatter;
use Monolog\LogRecord;

class CriticalErrorFormatter extends LineFormatter
{
    public function __construct(
        ?string $format = null,
        ?string $dateFormat = null,
        bool $allowInlineLineBreaks = false
    ) {
        parent::__construct($format, $dateFormat, $allowInlineLineBreaks, true); // Last parameter forces stacktraces
    }

    public function format(LogRecord $record): string
    {
        // Only include stack traces for critical errors
        $includeStacktraces = $record->level->value >= 500; // 500 = CRITICAL level
        $this->includeStacktraces($includeStacktraces);

        return parent::format($record);
    }
}

<?php

namespace Bni\Gpec\Client\Type;

abstract class BaseRequest
{
    /**
     * @var null | \Bni\Gpec\Client\Type\Client
     */
    private ?\Bni\Gpec\Client\Type\Client $client = null;

    /**
     * @var null | string
     */
    private ?string $folder = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\Client
     */
    public function getClient() : ?\Bni\Gpec\Client\Type\Client
    {
        return $this->client;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\Client $client
     * @return static
     */
    public function withClient(?\Bni\Gpec\Client\Type\Client $client) : static
    {
        $new = clone $this;
        $new->client = $client;

        return $new;
    }

    /**
     * @return null | string
     */
    public function getFolder() : ?string
    {
        return $this->folder;
    }

    /**
     * @param null | string $folder
     * @return static
     */
    public function withFolder(?string $folder) : static
    {
        $new = clone $this;
        $new->folder = $folder;

        return $new;
    }
}


<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class GetMailCountResponse implements ResultInterface
{
    /**
     * @var null | \Bni\Gpec\Client\Type\GetMailCountResponse
     */
    private ?\Bni\Gpec\Client\Type\GetMailCountResponse $GetMailCountResponse = null;

    /**
     * @var int
     */
    private int $count;

    /**
     * @return null | \Bni\Gpec\Client\Type\GetMailCountResponse
     */
    public function getGetMailCountResponse() : ?\Bni\Gpec\Client\Type\GetMailCountResponse
    {
        return $this->GetMailCountResponse;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\GetMailCountResponse $GetMailCountResponse
     * @return static
     */
    public function withGetMailCountResponse(?\Bni\Gpec\Client\Type\GetMailCountResponse $GetMailCountResponse) : static
    {
        $new = clone $this;
        $new->GetMailCountResponse = $GetMailCountResponse;

        return $new;
    }

    /**
     * @return int
     */
    public function getCount() : int
    {
        return $this->count;
    }

    /**
     * @param int $count
     * @return static
     */
    public function withCount(int $count) : static
    {
        $new = clone $this;
        $new->count = $count;

        return $new;
    }
}


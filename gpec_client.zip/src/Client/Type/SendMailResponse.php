<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class SendMailResponse implements ResultInterface
{
    /**
     * @var null | \Bni\Gpec\Client\Type\SendMailResponse
     */
    private ?\Bni\Gpec\Client\Type\SendMailResponse $SendMailResponse = null;

    /**
     * @var null | string
     */
    private ?string $id = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\SendMailResponse
     */
    public function getSendMailResponse() : ?\Bni\Gpec\Client\Type\SendMailResponse
    {
        return $this->SendMailResponse;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\SendMailResponse $SendMailResponse
     * @return static
     */
    public function withSendMailResponse(?\Bni\Gpec\Client\Type\SendMailResponse $SendMailResponse) : static
    {
        $new = clone $this;
        $new->SendMailResponse = $SendMailResponse;

        return $new;
    }

    /**
     * @return null | string
     */
    public function getId() : ?string
    {
        return $this->id;
    }

    /**
     * @param null | string $id
     * @return static
     */
    public function withId(?string $id) : static
    {
        $new = clone $this;
        $new->id = $id;

        return $new;
    }
}


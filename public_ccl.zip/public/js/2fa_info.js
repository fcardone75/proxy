
document.addEventListener('DOMContentLoaded', () => {

    $('#app-2fa-button-info').on('click', function(e) {
        $('#app2faModalInfo').modal('show');
    });

});

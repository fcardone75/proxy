<?php

namespace Bni\Gpec\Client\Type;

use \Bni\Gpec\Client\Type\GetMailRequest;

class GetMailCountRequest extends GetMailRequest
{
}


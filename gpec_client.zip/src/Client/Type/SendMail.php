<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class SendMail implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\SendMailRequest
     */
    private \Bni\Gpec\Client\Type\SendMailRequest $SendMailRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\SendMailRequest $SendMailRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\SendMailRequest $SendMailRequest)
    {
        $this->SendMailRequest = $SendMailRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\SendMailRequest
     */
    public function getSendMailRequest() : \Bni\Gpec\Client\Type\SendMailRequest
    {
        return $this->SendMailRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\SendMailRequest $SendMailRequest
     * @return static
     */
    public function withSendMailRequest(\Bni\Gpec\Client\Type\SendMailRequest $SendMailRequest) : static
    {
        $new = clone $this;
        $new->SendMailRequest = $SendMailRequest;

        return $new;
    }
}


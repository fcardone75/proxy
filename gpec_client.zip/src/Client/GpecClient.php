<?php

namespace Bni\Gpec\Client;

use Phpro\SoapClient\Caller\Caller;
use Bni\Gpec\Client\Type;
use Phpro\SoapClient\Type\ResultInterface;
use Phpro\SoapClient\Exception\SoapException;
use Phpro\SoapClient\Type\RequestInterface;

class GpecClient
{
    /**
     * @var Caller
     */
    private $caller;

    public function __construct(\Phpro\SoapClient\Caller\Caller $caller)
    {
        $this->caller = $caller;
    }

    /**
     * This method is only for try the if the service is up and is callable
     *
     * @param RequestInterface & Type\GetVersion $parameters
     * @return ResultInterface & Type\GetVersionResponse
     * @throws SoapException
     */
    public function getVersion(\Bni\Gpec\Client\Type\GetVersion $parameters) : \Bni\Gpec\Client\Type\GetVersionResponse
    {
        $response = ($this->caller)('getVersion', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\GetVersionResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/sendMail.html">link</a>
     *
     * @param RequestInterface & Type\SendMail $parameters
     * @return ResultInterface & Type\SendMailResponse
     * @throws SoapException
     */
    public function sendMail(\Bni\Gpec\Client\Type\SendMail $parameters) : \Bni\Gpec\Client\Type\SendMailResponse
    {
        $response = ($this->caller)('sendMail', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\SendMailResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/deleteMail.html">link</a>
     *
     * @param RequestInterface & Type\DeleteMail $parameters
     * @return ResultInterface & Type\DeleteMailResponse
     * @throws SoapException
     */
    public function deleteMail(\Bni\Gpec\Client\Type\DeleteMail $parameters) : \Bni\Gpec\Client\Type\DeleteMailResponse
    {
        $response = ($this->caller)('deleteMail', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\DeleteMailResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/getMailCount.html">link</a>
     *
     * @param RequestInterface & Type\GetMailCount $parameters
     * @return ResultInterface & Type\GetMailCountResponse
     * @throws SoapException
     */
    public function getMailCount(\Bni\Gpec\Client\Type\GetMailCount $parameters) : \Bni\Gpec\Client\Type\GetMailCountResponse
    {
        $response = ($this->caller)('getMailCount', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\GetMailCountResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/getMailById.html">link</a>
     *
     * @param RequestInterface & Type\GetMailById $parameters
     * @return ResultInterface & Type\GetMailByIdResponse
     * @throws SoapException
     */
    public function getMailById(\Bni\Gpec\Client\Type\GetMailById $parameters) : \Bni\Gpec\Client\Type\GetMailByIdResponse
    {
        $response = ($this->caller)('getMailById', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\GetMailByIdResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/getMailsAndReceipts.html">link</a>
     *
     * @param RequestInterface & Type\GetMailsAndReceipts $parameters
     * @return ResultInterface & Type\GetMailsAndReceiptsResponse
     * @throws SoapException
     */
    public function getMailsAndReceipts(\Bni\Gpec\Client\Type\GetMailsAndReceipts $parameters) : \Bni\Gpec\Client\Type\GetMailsAndReceiptsResponse
    {
        $response = ($this->caller)('getMailsAndReceipts', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\GetMailsAndReceiptsResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/getMails.html">link</a>
     *
     * @param RequestInterface & Type\GetMails $parameters
     * @return ResultInterface & Type\GetMailsResponse
     * @throws SoapException
     */
    public function getMails(\Bni\Gpec\Client\Type\GetMails $parameters) : \Bni\Gpec\Client\Type\GetMailsResponse
    {
        $response = ($this->caller)('getMails', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\GetMailsResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/getMailsFrom.html">link</a>
     *
     * @param RequestInterface & Type\GetMailsFrom $parameters
     * @return ResultInterface & Type\GetMailsFromResponse
     * @throws SoapException
     */
    public function getMailsFrom(\Bni\Gpec\Client\Type\GetMailsFrom $parameters) : \Bni\Gpec\Client\Type\GetMailsFromResponse
    {
        $response = ($this->caller)('getMailsFrom', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\GetMailsFromResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/getMailsTo.html">link</a>
     *
     * @param RequestInterface & Type\GetMailsTo $parameters
     * @return ResultInterface & Type\GetMailsToResponse
     * @throws SoapException
     */
    public function getMailsTo(\Bni\Gpec\Client\Type\GetMailsTo $parameters) : \Bni\Gpec\Client\Type\GetMailsToResponse
    {
        $response = ($this->caller)('getMailsTo', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\GetMailsToResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/getMailsRange.html">link</a>
     *
     * @param RequestInterface & Type\GetMailsRange $parameters
     * @return ResultInterface & Type\GetMailsRangeResponse
     * @throws SoapException
     */
    public function getMailsRange(\Bni\Gpec\Client\Type\GetMailsRange $parameters) : \Bni\Gpec\Client\Type\GetMailsRangeResponse
    {
        $response = ($this->caller)('getMailsRange', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\GetMailsRangeResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }

    /**
     * Documentation available at the following <a href="Documentation/moveMessage.html">link</a>
     *
     * @param RequestInterface & Type\MoveMessage $parameters
     * @return ResultInterface & Type\MoveMessageResponse
     * @throws SoapException
     */
    public function moveMessage(\Bni\Gpec\Client\Type\MoveMessage $parameters) : \Bni\Gpec\Client\Type\MoveMessageResponse
    {
        $response = ($this->caller)('moveMessage', $parameters);

        \Psl\Type\instance_of(\Bni\Gpec\Client\Type\MoveMessageResponse::class)->assert($response);
        \Psl\Type\instance_of(\Phpro\SoapClient\Type\ResultInterface::class)->assert($response);

        return $response;
    }
}


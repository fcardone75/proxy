<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class GetMailsResponse implements ResultInterface
{
    /**
     * @var null | \Bni\Gpec\Client\Type\GetMailsResponse
     */
    private ?\Bni\Gpec\Client\Type\GetMailsResponse $GetMailsResponse = null;

    /**
     * @var null | \Bni\Gpec\Client\Type\ArrayOfMessageInfo
     */
    private ?\Bni\Gpec\Client\Type\ArrayOfMessageInfo $messages = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\GetMailsResponse
     */
    public function getGetMailsResponse() : ?\Bni\Gpec\Client\Type\GetMailsResponse
    {
        return $this->GetMailsResponse;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\GetMailsResponse $GetMailsResponse
     * @return static
     */
    public function withGetMailsResponse(?\Bni\Gpec\Client\Type\GetMailsResponse $GetMailsResponse) : static
    {
        $new = clone $this;
        $new->GetMailsResponse = $GetMailsResponse;

        return $new;
    }

    /**
     * @return null | \Bni\Gpec\Client\Type\ArrayOfMessageInfo
     */
    public function getMessages() : ?\Bni\Gpec\Client\Type\ArrayOfMessageInfo
    {
        return $this->messages;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\ArrayOfMessageInfo $messages
     * @return static
     */
    public function withMessages(?\Bni\Gpec\Client\Type\ArrayOfMessageInfo $messages) : static
    {
        $new = clone $this;
        $new->messages = $messages;

        return $new;
    }
}


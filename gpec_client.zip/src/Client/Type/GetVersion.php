<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class GetVersion implements RequestInterface
{
    /**
     * Constructor
     */
    public function __construct()
    {
    }
}


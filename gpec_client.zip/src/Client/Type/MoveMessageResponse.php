<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class MoveMessageResponse implements ResultInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\MoveMessageResponse
     */
    private \Bni\Gpec\Client\Type\MoveMessageResponse $MoveMessageResponse;

    /**
     * @return \Bni\Gpec\Client\Type\MoveMessageResponse
     */
    public function getMoveMessageResponse() : \Bni\Gpec\Client\Type\MoveMessageResponse
    {
        return $this->MoveMessageResponse;
    }

    /**
     * @param \Bni\Gpec\Client\Type\MoveMessageResponse $MoveMessageResponse
     * @return static
     */
    public function withMoveMessageResponse(\Bni\Gpec\Client\Type\MoveMessageResponse $MoveMessageResponse) : static
    {
        $new = clone $this;
        $new->MoveMessageResponse = $MoveMessageResponse;

        return $new;
    }
}


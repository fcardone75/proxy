<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class GetMailsFromResponse implements ResultInterface
{
    /**
     * @var null | \Bni\Gpec\Client\Type\GetMailsFromResponse
     */
    private ?\Bni\Gpec\Client\Type\GetMailsFromResponse $GetMailsFromResponse = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\GetMailsFromResponse
     */
    public function getGetMailsFromResponse() : ?\Bni\Gpec\Client\Type\GetMailsFromResponse
    {
        return $this->GetMailsFromResponse;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\GetMailsFromResponse $GetMailsFromResponse
     * @return static
     */
    public function withGetMailsFromResponse(?\Bni\Gpec\Client\Type\GetMailsFromResponse $GetMailsFromResponse) : static
    {
        $new = clone $this;
        $new->GetMailsFromResponse = $GetMailsFromResponse;

        return $new;
    }
}


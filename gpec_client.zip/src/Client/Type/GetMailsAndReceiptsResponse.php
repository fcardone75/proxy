<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class GetMailsAndReceiptsResponse implements ResultInterface
{
    /**
     * @var null | \Bni\Gpec\Client\Type\GetMailsAndReceiptsResponse
     */
    private ?\Bni\Gpec\Client\Type\GetMailsAndReceiptsResponse $GetMailsAndReceiptsResponse = null;

    /**
     * @var null | \Bni\Gpec\Client\Type\ArrayOfMessageInfo
     */
    private ?\Bni\Gpec\Client\Type\ArrayOfMessageInfo $messages = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\GetMailsAndReceiptsResponse
     */
    public function getGetMailsAndReceiptsResponse() : ?\Bni\Gpec\Client\Type\GetMailsAndReceiptsResponse
    {
        return $this->GetMailsAndReceiptsResponse;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\GetMailsAndReceiptsResponse $GetMailsAndReceiptsResponse
     * @return static
     */
    public function withGetMailsAndReceiptsResponse(?\Bni\Gpec\Client\Type\GetMailsAndReceiptsResponse $GetMailsAndReceiptsResponse) : static
    {
        $new = clone $this;
        $new->GetMailsAndReceiptsResponse = $GetMailsAndReceiptsResponse;

        return $new;
    }

    /**
     * @return null | \Bni\Gpec\Client\Type\ArrayOfMessageInfo
     */
    public function getMessages() : ?\Bni\Gpec\Client\Type\ArrayOfMessageInfo
    {
        return $this->messages;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\ArrayOfMessageInfo $messages
     * @return static
     */
    public function withMessages(?\Bni\Gpec\Client\Type\ArrayOfMessageInfo $messages) : static
    {
        $new = clone $this;
        $new->messages = $messages;

        return $new;
    }
}


<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class GetMailsTo implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\GetMailsToRequest
     */
    private \Bni\Gpec\Client\Type\GetMailsToRequest $GetMailToRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\GetMailsToRequest $GetMailToRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\GetMailsToRequest $GetMailToRequest)
    {
        $this->GetMailToRequest = $GetMailToRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\GetMailsToRequest
     */
    public function getGetMailToRequest() : \Bni\Gpec\Client\Type\GetMailsToRequest
    {
        return $this->GetMailToRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\GetMailsToRequest $GetMailToRequest
     * @return static
     */
    public function withGetMailToRequest(\Bni\Gpec\Client\Type\GetMailsToRequest $GetMailToRequest) : static
    {
        $new = clone $this;
        $new->GetMailToRequest = $GetMailToRequest;

        return $new;
    }
}


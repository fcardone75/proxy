<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class GetMailById implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\GetMailByIdRequest
     */
    private \Bni\Gpec\Client\Type\GetMailByIdRequest $GetMailByIdRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\GetMailByIdRequest $GetMailByIdRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\GetMailByIdRequest $GetMailByIdRequest)
    {
        $this->GetMailByIdRequest = $GetMailByIdRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\GetMailByIdRequest
     */
    public function getGetMailByIdRequest() : \Bni\Gpec\Client\Type\GetMailByIdRequest
    {
        return $this->GetMailByIdRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\GetMailByIdRequest $GetMailByIdRequest
     * @return static
     */
    public function withGetMailByIdRequest(\Bni\Gpec\Client\Type\GetMailByIdRequest $GetMailByIdRequest) : static
    {
        $new = clone $this;
        $new->GetMailByIdRequest = $GetMailByIdRequest;

        return $new;
    }
}


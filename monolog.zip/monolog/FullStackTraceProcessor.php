<?php
// src/Monolog/Processor/FullStackTraceProcessor.php
namespace App\Monolog\Processor;

use Monolog\LogRecord;

class FullStackTraceProcessor
{
    public function __invoke(LogRecord $record): LogRecord
    {
        if (!$_ENV['ENABLE_FULL_STACK_TRACE_PROCESSOR']) {
            return $record;
        }

        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);

        // Filter out Doctrine and Monolog classes
        $applicationTrace = array_filter($trace, function ($call) {
            $class = $call['class'] ?? '';
            return
                !str_starts_with($class, 'Doctrine\\DBAL\\') &&
                !str_starts_with($class, 'Doctrine\\ORM\\') &&
                !str_starts_with($class, 'Monolog\\');
        });

        $record->extra['application_trace'] = array_map(function ($call) {
            return [
                'class' => $call['class'] ?? '',
                'function' => $call['function'] ?? '',
                'file' => $call['file'] ?? '',
                'line' => $call['line'] ?? '',
            ];
        }, array_values($applicationTrace));

        return $record;
    }
}


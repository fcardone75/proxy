<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\ResultInterface;

class GetMailByIdResponse implements ResultInterface
{
    /**
     * @var null | \Bni\Gpec\Client\Type\GetMailByIdResponse
     */
    private ?\Bni\Gpec\Client\Type\GetMailByIdResponse $GetMailByIdResponse = null;

    /**
     * @var null | \Bni\Gpec\Client\Type\MessageInfo
     */
    private ?\Bni\Gpec\Client\Type\MessageInfo $message = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\GetMailByIdResponse
     */
    public function getGetMailByIdResponse() : ?\Bni\Gpec\Client\Type\GetMailByIdResponse
    {
        return $this->GetMailByIdResponse;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\GetMailByIdResponse $GetMailByIdResponse
     * @return static
     */
    public function withGetMailByIdResponse(?\Bni\Gpec\Client\Type\GetMailByIdResponse $GetMailByIdResponse) : static
    {
        $new = clone $this;
        $new->GetMailByIdResponse = $GetMailByIdResponse;

        return $new;
    }

    /**
     * @return null | \Bni\Gpec\Client\Type\MessageInfo
     */
    public function getMessage() : ?\Bni\Gpec\Client\Type\MessageInfo
    {
        return $this->message;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\MessageInfo $message
     * @return static
     */
    public function withMessage(?\Bni\Gpec\Client\Type\MessageInfo $message) : static
    {
        $new = clone $this;
        $new->message = $message;

        return $new;
    }
}


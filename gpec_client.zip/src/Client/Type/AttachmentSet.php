<?php

namespace Bni\Gpec\Client\Type;

class AttachmentSet
{
    /**
     * @var null | \Bni\Gpec\Client\Type\ArrayOfAttachment
     */
    private ?\Bni\Gpec\Client\Type\ArrayOfAttachment $attachments = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\ArrayOfAttachment
     */
    public function getAttachments() : ?\Bni\Gpec\Client\Type\ArrayOfAttachment
    {
        return $this->attachments;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\ArrayOfAttachment $attachments
     * @return static
     */
    public function withAttachments(?\Bni\Gpec\Client\Type\ArrayOfAttachment $attachments) : static
    {
        $new = clone $this;
        $new->attachments = $attachments;

        return $new;
    }
}


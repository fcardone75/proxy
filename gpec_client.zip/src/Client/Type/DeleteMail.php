<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class DeleteMail implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\DeleteMailRequest
     */
    private \Bni\Gpec\Client\Type\DeleteMailRequest $deleteMailRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\DeleteMailRequest $deleteMailRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\DeleteMailRequest $deleteMailRequest)
    {
        $this->deleteMailRequest = $deleteMailRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\DeleteMailRequest
     */
    public function getDeleteMailRequest() : \Bni\Gpec\Client\Type\DeleteMailRequest
    {
        return $this->deleteMailRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\DeleteMailRequest $deleteMailRequest
     * @return static
     */
    public function withDeleteMailRequest(\Bni\Gpec\Client\Type\DeleteMailRequest $deleteMailRequest) : static
    {
        $new = clone $this;
        $new->deleteMailRequest = $deleteMailRequest;

        return $new;
    }
}


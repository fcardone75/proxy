<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class GetMailsRange implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\GetMailsRangeRequest
     */
    private \Bni\Gpec\Client\Type\GetMailsRangeRequest $GetMailsFromDateToDateRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\GetMailsRangeRequest $GetMailsFromDateToDateRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\GetMailsRangeRequest $GetMailsFromDateToDateRequest)
    {
        $this->GetMailsFromDateToDateRequest = $GetMailsFromDateToDateRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\GetMailsRangeRequest
     */
    public function getGetMailsFromDateToDateRequest() : \Bni\Gpec\Client\Type\GetMailsRangeRequest
    {
        return $this->GetMailsFromDateToDateRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\GetMailsRangeRequest $GetMailsFromDateToDateRequest
     * @return static
     */
    public function withGetMailsFromDateToDateRequest(\Bni\Gpec\Client\Type\GetMailsRangeRequest $GetMailsFromDateToDateRequest) : static
    {
        $new = clone $this;
        $new->GetMailsFromDateToDateRequest = $GetMailsFromDateToDateRequest;

        return $new;
    }
}


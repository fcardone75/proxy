<?php

namespace Bni\Gpec\Client\Type;

use Phpro\SoapClient\Type\RequestInterface;

class GetMailCount implements RequestInterface
{
    /**
     * @var \Bni\Gpec\Client\Type\GetMailCountRequest
     */
    private \Bni\Gpec\Client\Type\GetMailCountRequest $getMailCountRequest;

    /**
     * Constructor
     *
     * @param \Bni\Gpec\Client\Type\GetMailCountRequest $getMailCountRequest
     */
    public function __construct(\Bni\Gpec\Client\Type\GetMailCountRequest $getMailCountRequest)
    {
        $this->getMailCountRequest = $getMailCountRequest;
    }

    /**
     * @return \Bni\Gpec\Client\Type\GetMailCountRequest
     */
    public function getGetMailCountRequest() : \Bni\Gpec\Client\Type\GetMailCountRequest
    {
        return $this->getMailCountRequest;
    }

    /**
     * @param \Bni\Gpec\Client\Type\GetMailCountRequest $getMailCountRequest
     * @return static
     */
    public function withGetMailCountRequest(\Bni\Gpec\Client\Type\GetMailCountRequest $getMailCountRequest) : static
    {
        $new = clone $this;
        $new->getMailCountRequest = $getMailCountRequest;

        return $new;
    }
}


<?php

namespace Bni\Gpec\Client;



use Bni\Gpec\Gpec\CustomGpecFactory;

class GpecClientFactory
{
    public static function factory(string $wsdl): GpecClient
    {
        return (new CustomGpecFactory())->getFactory($wsdl);

//        $engine = DefaultEngineFactory::create(
//            ExtSoapOptions::defaults($wsdl, [])
//                ->withClassMap(GpecClassmap::getCollection())
//        );
//
//        $eventDispatcher = new EventDispatcher();
//        $caller = new EventDispatchingCaller(new EngineCaller($engine), $eventDispatcher);


    }
}


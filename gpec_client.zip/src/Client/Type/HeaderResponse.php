<?php

namespace Bni\Gpec\Client\Type;

class HeaderResponse
{
    /**
     * @var null | \Bni\Gpec\Client\Type\OperationResult
     */
    private ?\Bni\Gpec\Client\Type\OperationResult $operationResult = null;

    /**
     * @return null | \Bni\Gpec\Client\Type\OperationResult
     */
    public function getOperationResult() : ?\Bni\Gpec\Client\Type\OperationResult
    {
        return $this->operationResult;
    }

    /**
     * @param null | \Bni\Gpec\Client\Type\OperationResult $operationResult
     * @return static
     */
    public function withOperationResult(?\Bni\Gpec\Client\Type\OperationResult $operationResult) : static
    {
        $new = clone $this;
        $new->operationResult = $operationResult;

        return $new;
    }
}


<?php

namespace Bni\Gpec\Gpec;

use Bni\Gpec\Client\GpecClient;
use Bni\Gpec\Client\GpecClientFactory;
use Bni\Gpec\Client\Type\Client;
use Bni\Gpec\Client\Type\MessageInfo;
use Bni\Gpec\Client\Type\MessageInfoSender;
use Bni\Gpec\Client\Type\SendMail;
use Bni\Gpec\Client\Type\SendMailRequest;
use Bni\Gpec\Client\Type\SendMailResponse;
use DateTime;
use Dotenv\Dotenv;
use Phpro\SoapClient\Type\ResultInterface;

class GpecService
{
    private GpecClient $gpecClient;
    private Client $clientType;

    public function __construct(string $envPath = null)
    {
        // Se le env non sono passate, presume che siano a 4 livelli superiori a questo (Client -> root pacchetto composer -> Vendor -> root progetto)
        $envPath = $envPath ?? dirname(__DIR__, 4);
        $dotenv = Dotenv::createImmutable($envPath);
        $dotenv->load();

        // Genera e assegna il client
        $this->gpecClient = GpecClientFactory::factory('gpec.wsdl');
        $this->clientType = (new Client())->withUser(getenv(EnvUtility::BNI_GPEC_USER))->withPassword(EnvUtility::BNI_GPEC_PASSWORD);
    }


    /**
     *
     * Invia la mail con i parametri passati
     *
     * @param string $to
     * @param string $subject
     * @param string $body
     * @param DateTime $sentDate
     * @param DateTime $acceptedDate
     * @return SendMailResponse
     */
    public function sendMail(string $to, string $subject, string $body, DateTime $sentDate, DateTime $acceptedDate): SendMailResponse
    {
        // Crea l'oggetto MessageInfo con i dati passati
        $messageInfoSender = (new MessageInfoSender())
            ->withTo($to)
            ->withSubject($subject)
            ->withBody($body)
            ->withIsBodyHtml(false)
            ->withSubjectEncoding(getenv(EnvUtility::BNI_GPEC_SUBJECT_ENCODING))
            ->withBodyEncoding(getenv(EnvUtility::BNI_GPEC_BODY_ENCODING))
            ->withHeadersEncoding(getenv(EnvUtility::BNI_GPEC_HEADERS_ENCODING))
            ->withPriority(getenv(EnvUtility::BNI_GPEC_PRIORITY));
//            ->withSentDate($sentDate)
//            ->withAcceptedDate($acceptedDate);


        // Crea la richiesta usando il MessageInfo, visto che estende MessageInfoSender, può essere passato a withMessage
        // Passa anche il client

        $sendMailRequest = (new SendMailRequest())->withMessage($messageInfoSender)->withClient($this->clientType);

        // Crea infine l'oggetto SendMail utile al metodo sendMail
        $sendMail = new SendMail($sendMailRequest);
        return $this->gpecClient->sendMail($sendMail);
    }

    /**
     * @return GpecClient
     */
    public function getGpecClient(): GpecClient
    {
        return $this->gpecClient;
    }


    /**
     * @return Client
     */
    public function getClientType(): Client
    {
        return $this->clientType;
    }
}

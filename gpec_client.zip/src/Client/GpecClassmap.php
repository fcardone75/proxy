<?php

namespace Bni\Gpec\Client;

use Bni\Gpec\Client\Type;
use Soap\ExtSoapEngine\Configuration\ClassMap\ClassMapCollection;
use Soap\ExtSoapEngine\Configuration\ClassMap\ClassMap;

class GpecClassmap
{
    public static function getCollection() : \Soap\ExtSoapEngine\Configuration\ClassMap\ClassMapCollection
    {
        return new ClassMapCollection(
            new ClassMap('getVersion', Type\GetVersion::class),
            new ClassMap('getVersionResponse', Type\GetVersionResponse::class),
            new ClassMap('sendMail', Type\SendMail::class),
            new ClassMap('sendMailResponse', Type\SendMailResponse::class),
            new ClassMap('deleteMail', Type\DeleteMail::class),
            new ClassMap('deleteMailResponse', Type\DeleteMailResponse::class),
            new ClassMap('getMailCount', Type\GetMailCount::class),
            new ClassMap('getMailCountResponse', Type\GetMailCountResponse::class),
            new ClassMap('getMailById', Type\GetMailById::class),
            new ClassMap('getMailByIdResponse', Type\GetMailByIdResponse::class),
            new ClassMap('getMailsAndReceipts', Type\GetMailsAndReceipts::class),
            new ClassMap('getMailsAndReceiptsResponse', Type\GetMailsAndReceiptsResponse::class),
            new ClassMap('getMails', Type\GetMails::class),
            new ClassMap('getMailsResponse', Type\GetMailsResponse::class),
            new ClassMap('getMailsFrom', Type\GetMailsFrom::class),
            new ClassMap('getMailsFromResponse', Type\GetMailsFromResponse::class),
            new ClassMap('getMailsTo', Type\GetMailsTo::class),
            new ClassMap('getMailsToResponse', Type\GetMailsToResponse::class),
            new ClassMap('getMailsRange', Type\GetMailsRange::class),
            new ClassMap('getMailsRangeResponse', Type\GetMailsRangeResponse::class),
            new ClassMap('moveMessage', Type\MoveMessage::class),
            new ClassMap('moveMessageResponse', Type\MoveMessageResponse::class),
            new ClassMap('SendMailRequest', Type\SendMailRequest::class),
            new ClassMap('Client', Type\Client::class),
            new ClassMap('DeleteMailRequest', Type\DeleteMailRequest::class),
            new ClassMap('GetMailCountRequest', Type\GetMailCountRequest::class),
            new ClassMap('GetMailByIdRequest', Type\GetMailByIdRequest::class),
            new ClassMap('GetMailsAndReceiptsRequest', Type\GetMailsAndReceiptsRequest::class),
            new ClassMap('GetMailsRequest', Type\GetMailsRequest::class),
            new ClassMap('GetMailsFromRequest', Type\GetMailsFromRequest::class),
            new ClassMap('GetMailsToRequest', Type\GetMailsToRequest::class),
            new ClassMap('GetMailsRangeRequest', Type\GetMailsRangeRequest::class),
            new ClassMap('MoveMessageRequest', Type\MoveMessageRequest::class),
            new ClassMap('GetMailToRequest', Type\GetMailToRequest::class),
            new ClassMap('GetMailsFromDateToDateRequest', Type\GetMailsFromDateToDateRequest::class),
            new ClassMap('BaseRequest', Type\BaseRequest::class),
            new ClassMap('BaseResponse', Type\BaseResponse::class),
            new ClassMap('GetMailRequest', Type\GetMailRequest::class),
            new ClassMap('MessageInfoSender', Type\MessageInfoSender::class),
            new ClassMap('AttachmentSet', Type\AttachmentSet::class),
            new ClassMap('ArrayOfAttachment', Type\ArrayOfAttachment::class),
            new ClassMap('Attachment', Type\Attachment::class),
            new ClassMap('ArrayOfObjectHeaders', Type\ArrayOfObjectHeaders::class),
            new ClassMap('ObjectHeaders', Type\ObjectHeaders::class),
            new ClassMap('MessageInfo', Type\MessageInfo::class),
            new ClassMap('ArrayOfMessageInfo', Type\ArrayOfMessageInfo::class),
            new ClassMap('GetMailsFromDateToDateResponse', Type\GetMailsFromDateToDateResponse::class),
            new ClassMap('GPECHeaderRequest', Type\GPECHeaderRequest::class),
            new ClassMap('GPECHeaderResponse', Type\GPECHeaderResponse::class),
            new ClassMap('OperationResult', Type\OperationResult::class),
            new ClassMap('headerRequest', Type\HeaderRequest::class),
            new ClassMap('headerResponse', Type\HeaderResponse::class),
        );
    }
}

